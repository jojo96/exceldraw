from setuptools import setup

setup(name='exceldraw',
      version='1.6',
      description='Draw your Excel image',
      packages=['exceldraw'],
      author_email='ujjayanta.bhaumik.18@ucl.ac.uk',
      zip_safe=False)
